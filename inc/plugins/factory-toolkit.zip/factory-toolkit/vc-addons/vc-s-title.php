<?php 

vc_map( array(
  "name" => __( "Section Title", "factory" ),
  "base" => "title-section",
  "category" => __( "Factory", "factory"),
  "params" => array(
	 array(
	  "type" => "textfield",
	  "heading" => __( "Section Title", "factory" ),
	  "param_name" => "sec_tit",
	  "value" => __( "Enter Your Section Title", "factory" ),
	  "description" => __( "Description for foo param.", "factory" )
	 ),
	 array(
	  "type" => "textfield",
	  "heading" => __( "Section Description", "factory" ),
	  "param_name" => "sec_des",
	 ),

  )
 ) );