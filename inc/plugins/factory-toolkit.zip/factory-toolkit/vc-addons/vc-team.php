<?php 

vc_map(
    array(
     "name" => __( "Team", "factory" ),
     "base" => "team",
     "category" => __( "Factory", "factory"),
     "params" => array(
         
         array(
            "type" => "dropdown",
            "heading" => esc_html__( "Factory Service Details team", "factory" ),
            "param_name" => "team_style",
            "std" => esc_html__( "1", "factory" ),
            "value" => array(
                esc_html__('Factory team', 'factory-founder') => 1,
                esc_html__('Service Details team', 'factory-founder') => 2,
                ),
            "description" => esc_html__( "Select team Style.", "factory" )
        ),
        array(
            "type" => "textfield",
            "heading" => __( "Name", "factory" ),
            "param_name" => "head",
            "std" => esc_html__( "Facfory Founder", "factory" ),
        ),
        array(
            "type" => "textarea",
            "heading" => __( "Position", "factory" ),
            "param_name" => "des",
            "std" => esc_html__( "Developer", "factory" ),
        ),
        array(
        "type" => "textfield",
        "heading" => esc_html__( "Description about team member", "factory" ),
        "param_name" => "description",
        "std" => esc_html__( "Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ad inventore tenetur there fugiat quidem accusamus sapiente is biger assumenda consequatur illo ullam.", "factory" ),
        "description" => esc_html__( "Description About Membar", "factory" ),
        "dependency" => array(
            "element" => "team_style",
            "value" => array("1"),
            )
        ),
        array(
        "type" => "attach_image",
        "heading" => esc_html__( "Upload Profile image", "factory" ),
        "param_name" => "upload_profile_img",
        "description" => esc_html__( "upload Your img.", "factory" )
        ),
        array(
        "type" => "dropdown",
        "heading" => esc_html__( "Link type", "factory" ),
        "param_name" => "type",
        "std" => esc_html__( "1", "factory" ),
        "value" => array(
            esc_html__('Link to page', 'factory-founder') => 1,
            esc_html__('External link', 'factory-founder') => 2,
            ),
        "description" => esc_html__( "Select Link.", "factory" )
        ),
        array(
        "type" => "dropdown",
        "heading" => esc_html__( "Link to page", "factory" ),
        "param_name" => "link_to_page",
        "value" => factory_get_page_as_list(),
        "description" => esc_html__( "Select Link.", "factory" ),
        "dependency" => array(
            "element" => "type",
            "value" => array("1"),
            )
        ),
        array(
        "type" => "textfield",
        "heading" => esc_html__( "External link", "factory" ),
        "param_name" => "external_link",
        "description" => esc_html__( "Wright external Link.", "factory" ),
        "dependency" => array(
            "element" => "type",
            "value" => array("2"),
            )
        ),
        array(
        "type" => "textfield",
        "heading" => esc_html__( "Link text", "factory" ),
        "param_name" => "link_text",
        "std" => esc_html__( "See more", "factory" ),
        "description" => esc_html__( "Wright Text Link..", "factory" ),
        "dependency" => array(
            "element" => "team_style",
            "value" => array("1"),
            )
        ),

        // Social icon & link.. Start Now ... ..
         array(
           'type' => 'param_group',
           'param_name' => 'team_group',
           // Note params is mapped inside param-group:
           'params' => array(
            
                
                array(
                "type" => "iconpicker",
                "heading" => esc_html__( "Choose Social icon", "factory" ),
                "param_name" => "choose_icon",
                "description" => esc_html__( "Choose Social icon.", "factory" ),
                ),
                array(
                "type" => "textfield",
                "heading" => esc_html__( "Social Link text", "factory" ),
                "param_name" => "s_external_link",
                // "std" => esc_html__( "See more", "factory" ),
                "description" => esc_html__( "Enter Your Social Link Text ..", "factory" )
                ),
            


           )
         )
       
       )
   )
);