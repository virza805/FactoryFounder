<?php

 vc_map(
     array(
        "name" => esc_html__( "Stock Contact Icon", "stock-toolkit" ),
        "base" => "stock_contact",
        "category" => esc_html__( "Stock", "stock-toolkit"),
        "params" => array(
                array(
                "type" => "textarea",
                "heading" => esc_html__( "Title", "stock-toolkit" ),
                "param_name" => "desc",
                "description" => esc_html__( "Enter your title/Heading.", "stock-toolkit" )
                ),
                array(
                "type" => "textfield",
                "heading" => esc_html__( "Content", "stock-toolkit" ),
                "param_name" => "title",
                "description" => esc_html__( "Enter your description.", "stock-toolkit" )
                ),
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Link type", "stock-toolkit" ),
                "param_name" => "type",
                "std" => esc_html__( "1", "stock-toolkit" ),
                "value" => array(
                    esc_html__('Link to page', 'stock-toolkit') => 1,
                    esc_html__('External link', 'stock-toolkit') => 2,
                    ),
                "description" => esc_html__( "Select Link.", "stock-toolkit" )
                ),
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Link to page", "stock-toolkit" ),
                "param_name" => "link_to_page",
                "value" => factory_get_page_as_list(),
                "description" => esc_html__( "Select Link.", "stock-toolkit" ),
                "dependency" => array(
                    "element" => "type",
                    "value" => array("1"),
                    )
                ),
                array(
                "type" => "textfield",
                "heading" => esc_html__( "External link", "stock-toolkit" ),
                "param_name" => "external_link",
                "description" => esc_html__( "Wright external Link.", "stock-toolkit" ),
                "dependency" => array(
                    "element" => "type",
                    "value" => array("2"),
                    )
                ),
                
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Icon type", "stock-toolkit" ),
                "param_name" => "icon_type",
                "std" => esc_html__( "1", "stock-toolkit" ),
                "value" => array(
                    esc_html__('Upload', 'stock-toolkit') => 1,
                    esc_html__('FontAwesome', 'stock-toolkit') => 2,
                    ),
                "description" => esc_html__( "Select Icon type.", "stock-toolkit" )
                ),
                array(
                "type" => "attach_image",
                "heading" => esc_html__( "Upload icon", "stock-toolkit" ),
                "param_name" => "upload_icon",
                "description" => esc_html__( "upload imag as your wish.", "stock-toolkit" ),
                "dependency" => array(
                    "element" => "icon_type",
                    "value" => array("1"),
                    )
                ),
                array(
                "type" => "iconpicker",
                "heading" => esc_html__( "Choose icon", "stock-toolkit" ),
                "param_name" => "choose_icon",
                "description" => esc_html__( "Choose icon.", "stock-toolkit" ),
                "dependency" => array(
                    "element" => "icon_type",
                    "value" => array("2"),
                    )
                ),
                array(
                    "type" => "attach_image",
                    "heading" => esc_html__( "Box Background", "stock-toolkit" ),
                    "param_name" => "box_background",
                    "description" => esc_html__( "upload imag as your wish.", "stock-toolkit" ),
                ),
            )
        )
);

