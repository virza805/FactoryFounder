<?php

 vc_map(
     array(
        "name" => esc_html__( "Factory About Tool", "factory" ),
        "base" => "factory_f_a_tool",
        "category" => esc_html__( "Factory", "factory"),
        "params" => array(
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Factory About Tool Style", "factory" ),
                "param_name" => "f_a_style",
                "std" => esc_html__( "1", "factory" ),
                "value" => array(
                    esc_html__('Box Style for color-bg', 'factory-founder') => 1,
                    esc_html__('Box Style for white-bg', 'factory-founder') => 2,
                    esc_html__('Circle Style for whit-bg', 'factory-founder') => 3,
                    ),
                "description" => esc_html__( "Select Service Style.", "factory" )
                ),


                
                array(
                "type" => "textfield",
                "heading" => esc_html__( "Title", "factory" ),
                "param_name" => "title",
                "description" => esc_html__( "Enter your title/Heading.", "factory" )
                ),
                array(
                "type" => "textarea",
                "heading" => esc_html__( "Content", "factory" ),
                "param_name" => "desc",
                "description" => esc_html__( "Enter your description.", "factory" )
                ),
                
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Icon type", "factory" ),
                "param_name" => "icon_type",
                "std" => esc_html__( "1", "factory" ),
                "value" => array(
                    esc_html__('Upload', 'factory-founder') => 1,
                    esc_html__('FontAwesome', 'factory-founder') => 2,
                    ),
                "description" => esc_html__( "Select Icon type.", "factory" )
                ),
                array(
                "type" => "attach_image",
                "heading" => esc_html__( "Upload icon", "factory" ),
                "param_name" => "upload_icon",
                "description" => esc_html__( "upload imag as your wish.", "factory" ),
                "dependency" => array(
                    "element" => "icon_type",
                    "value" => array("1"),
                    )
                ),
                array(
                "type" => "iconpicker",
                "heading" => esc_html__( "Choose icon", "factory" ),
                "param_name" => "choose_icon",
                "description" => esc_html__( "Choose icon.", "factory" ),
                "dependency" => array(
                    "element" => "icon_type",
                    "value" => array("2"),
                    )
                ),
// Right Side Option start Now ###### =========  ######
                array(
                "type" => "textfield",
                "heading" => esc_html__( "Right Option Title", "factory" ),
                "param_name" => "title_b",
                "description" => esc_html__( "Right Option Enter your title/Heading.", "factory" ),
                "dependency" => array(
                    "element" => "f_a_style",
                    "value" => array("1", "2"),
                    )
                ),
                array(
                "type" => "textarea",
                "heading" => esc_html__( "Right Option Content", "factory" ),
                "param_name" => "desc_b",
                "description" => esc_html__( "Right Option Enter your description.", "factory" ),
                "dependency" => array(
                    "element" => "f_a_style",
                    "value" => array("1", "2"),
                    )
                ),
                
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Right Option Icon type", "factory" ),
                "param_name" => "icon_type_b",
                "std" => esc_html__( "Right Option 1", "factory" ),
                "value" => array(
                    esc_html__('Upload', 'factory-founder') => 1,
                    esc_html__('FontAwesome', 'factory-founder') => 2,
                    ),
                "description" => esc_html__( "Right Option Select Icon type.", "factory" ),
                "dependency" => array(
                    "element" => "f_a_style",
                    "value" => array("1", "2"),
                    )
                ),
                array(
                "type" => "attach_image",
                "heading" => esc_html__( "Right Option Upload icon", "factory" ),
                "param_name" => "upload_icon_b",
                "description" => esc_html__( "Right Option upload imag as your wish.", "factory" ),
                "dependency" => array(
                    "element" => "icon_type_b",
                    "value" => array("1"),
                    )
                ),
                array(
                "type" => "iconpicker",
                "heading" => esc_html__( "Right Option Choose icon", "factory" ),
                "param_name" => "choose_icon_b",
                "description" => esc_html__( "Right Option Choose icon.", "factory" ),
                "dependency" => array(
                    "element" => "icon_type_b",
                    "value" => array("2"),
                    )
                ),
                
            )
        )
);

