<?php 

vc_map(
    array(
     "name" => __( "Social for Factory", "factory" ),
     "base" => "social",
     "category" => __( "Factory", "factory"),
     "params" => array(
         
         
        
        
        

        // Social icon & link.. Start Now ... ..
         array(
           'type' => 'param_group',
           'param_name' => 'social_group',
           // Note params is mapped inside param-group:
           'params' => array(
            
                
                array(
                "type" => "iconpicker",
                "heading" => esc_html__( "Choose Social icon", "factory" ),
                "param_name" => "choose_icon",
                "description" => esc_html__( "Choose Social icon.", "factory" ),
                ),
                array(
                "type" => "textfield",
                "heading" => esc_html__( "Social Link text", "factory" ),
                "param_name" => "s_external_link",
                // "std" => esc_html__( "See more", "factory" ),
                "description" => esc_html__( "Enter Your Social Link Text ..", "factory" )
                ),
            


           )
         )
       
       )
   )
);