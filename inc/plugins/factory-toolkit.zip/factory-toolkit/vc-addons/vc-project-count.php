<?php 
vc_map( 
    array(
  "name" => __( "Show number of Project", "factory" ),
  "base" => "project",
  "category" => __( "Factory", "factory"),
  "params" => array(
	 array(
	  "type" => "textfield",
	  "heading" => __( "Project Post Count", "factory" ),
	  "param_name" => "count",
	 ),
	

  )
 ) 
 );