<?php 

vc_map(
    array(
     "name" => __( "Slider", "factory" ),
     "base" => "slider",
     "category" => __( "Factory", "factory"),
     "params" => array(
         array(
           'type' => 'param_group',
           'param_name' => 'slider_group',
           // Note params is mapped inside param-group:
           'params' => array(
               array(
             "type" => "attach_image",
             "heading" => __( "Pro. Image", "factory" ),
             "param_name" => "image",
           ),
           
          array(
            "type" => "textfield",
            "heading" => __( "Small Color Heading", "factory" ),
            "param_name" => "shead",
            "std" => esc_html__( "Facfory Founder", "factory" ),
          ),
          array(
            "type" => "textfield",
            "heading" => __( "Heading", "factory" ),
            "param_name" => "head",
            "std" => esc_html__( "Provide Solution for  All Industries", "factory" ),
          ),
          array(
            "type" => "textarea",
            "heading" => __( "Content", "factory" ),
            "param_name" => "des",
            "std" => esc_html__( "How to pursue pleasure rationally consequences that are extremeely painful<br>or because its sed great pleasure get well soon.", "factory" ),
          ),
             array(
             "type" => "textfield",
             "heading" => __( "Battun Laft", "factory" ),
             "param_name" => "btn",
             "std" => esc_html__( "Purses now", "factory" ),
           ),


           array(
            "type" => "dropdown",
            "heading" => esc_html__( "Left Button Link type", "factory" ),
            "param_name" => "type",
            "std" => esc_html__( "1", "factory" ),
            "value" => array(
                esc_html__('Link to page', 'factory-founder') => 1,
                esc_html__('External link', 'factory-founder') => 2,
                ),
            "description" => esc_html__( "Select Left Button Link.", "factory" )
            ),
            array(
            "type" => "dropdown",
            "heading" => esc_html__( "Link to page", "factory" ),
            "param_name" => "link_to_page",
            "value" => factory_get_page_as_list(),
            "description" => esc_html__( "Select Link.", "factory" ),
            "dependency" => array(
                "element" => "type",
                "value" => array("1"),
                )
            ),
            array(
            "type" => "textfield",
            "heading" => esc_html__( "External link", "factory" ),
            "param_name" => "external_link",
            "description" => esc_html__( "Wright external Link.", "factory" ),
            "dependency" => array(
                "element" => "type",
                "value" => array("2"),
                )
            ),



          //    array(
          //    "type" => "textfield",
          //    "heading" => __( "Battun laft url", "factory" ),
          //    "param_name" => "btn_url",
          //  ),
             array(
             "type" => "textfield",
             "heading" => __( "Button Right", "factory" ),
             "param_name" => "btnr",
             "std" => esc_html__( "know more", "factory" ),
           ),


           array(
            "type" => "dropdown",
            "heading" => esc_html__( "Right Button Link type", "factory" ),
            "param_name" => "typ",
            "std" => esc_html__( "1", "factory" ),
            "value" => array(
                esc_html__('Link to page', 'factory-founder') => 1,
                esc_html__('External link', 'factory-founder') => 2,
                ),
            "description" => esc_html__( "Select Right Button Link.", "factory" )
            ),
            array(
            "type" => "dropdown",
            "heading" => esc_html__( "Link to page", "factory" ),
            "param_name" => "link_to_pag",
            "value" => factory_get_page_as_list(),
            "description" => esc_html__( "Select Link.", "factory" ),
            "dependency" => array(
                "element" => "typ",
                "value" => array("1"),
                )
            ),
            array(
            "type" => "textfield",
            "heading" => esc_html__( "External link", "factory" ),
            "param_name" => "external_lin",
            "description" => esc_html__( "Wright external Link.", "factory" ),
            "dependency" => array(
                "element" => "typ",
                "value" => array("2"),
                )
            ),




          //    array(
          //    "type" => "textfield",
          //    "heading" => __( "Battun right url", "factory" ),
          //    "param_name" => "btnr_url",
          //  ),

       
           )
         )
       
       )
   )
);