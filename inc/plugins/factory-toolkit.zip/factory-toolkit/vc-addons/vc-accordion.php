<?php 

vc_map(
    array(
     "name" => __( "Accordion", "factory" ),
     "base" => "accordion",
     "category" => __( "Factory", "factory"),
     "params" => array(
         
         array(
            "type" => "dropdown",
            "heading" => esc_html__( "Factory Service Details Accordion", "factory" ),
            "param_name" => "accordion_style",
            "std" => esc_html__( "1", "factory" ),
            "value" => array(
                esc_html__('Factory Accordion', 'factory-founder') => 1,
                esc_html__('Service Details Accordion', 'factory-founder') => 2,
                ),
            "description" => esc_html__( "Select Accordion Style.", "factory" )
        ),
         array(
           'type' => 'param_group',
           'param_name' => 'accordion_group',
           // Note params is mapped inside param-group:
           'params' => array(
            
                array(
                    "type" => "textfield",
                    "heading" => __( "Heading", "factory" ),
                    "param_name" => "head",
                    "std" => esc_html__( "Facfory Founder", "factory" ),
                ),
                array(
                    "type" => "textarea",
                    "heading" => __( "Content", "factory" ),
                    "param_name" => "des",
                    "std" => esc_html__( "Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero. Duis autem vel eum iriure dolor in hendrerit in vulputate velit sse molestie consequat vel illum dolore.", "factory" ),
                ),
            


           )
         )
       
       )
   )
);