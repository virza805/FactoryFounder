<?php

 vc_map(
     array(
        "name" => esc_html__( "Factory service box", "factory" ),
        "base" => "factory_service_box",
        "category" => esc_html__( "Factory", "factory"),
        "params" => array(
                array(
                "type" => "textfield",
                "heading" => esc_html__( "Title", "factory" ),
                "param_name" => "title",
                "description" => esc_html__( "Enter your title/Heading.", "factory" )
                ),
                array(
                "type" => "textarea",
                "heading" => esc_html__( "Content", "factory" ),
                "param_name" => "desc",
                "description" => esc_html__( "Enter your description.", "factory" )
                ),
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Link type", "factory" ),
                "param_name" => "type",
                "std" => esc_html__( "1", "factory" ),
                "value" => array(
                    esc_html__('Link to page', 'factory-founder') => 1,
                    esc_html__('External link', 'factory-founder') => 2,
                    ),
                "description" => esc_html__( "Select Link.", "factory" )
                ),
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Link to page", "factory" ),
                "param_name" => "link_to_page",
                "value" => factory_get_page_as_list(),
                "description" => esc_html__( "Select Link.", "factory" ),
                "dependency" => array(
                    "element" => "type",
                    "value" => array("1"),
                    )
                ),
                array(
                "type" => "textfield",
                "heading" => esc_html__( "External link", "factory" ),
                "param_name" => "external_link",
                "description" => esc_html__( "Wright external Link.", "factory" ),
                "dependency" => array(
                    "element" => "type",
                    "value" => array("2"),
                    )
                ),
                array(
                "type" => "textfield",
                "heading" => esc_html__( "Link text", "factory" ),
                "param_name" => "link_text",
                "std" => esc_html__( "See more", "factory" ),
                "description" => esc_html__( "Wright Text Link..", "factory" )
                ),
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Service Style", "factory" ),
                "param_name" => "service_style",
                "std" => esc_html__( "1", "factory" ),
                "value" => array(
                    esc_html__('Style-1 without icon', 'factory-founder') => 1,
                    esc_html__('Style-2 with icon', 'factory-founder') => 2,
                    ),
                "description" => esc_html__( "Select Service Style.", "factory" )
                ),
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Icon type", "factory" ),
                "param_name" => "icon_type",
                "std" => esc_html__( "1", "factory" ),
                "value" => array(
                    esc_html__('Upload', 'factory-founder') => 1,
                    esc_html__('FontAwesome', 'factory-founder') => 2,
                    ),
                "description" => esc_html__( "Select Icon type.", "factory" ),
                "dependency" => array(
                    "element" => "service_style",
                    "value" => array("2"),
                    )
                ),
                array(
                "type" => "attach_image",
                "heading" => esc_html__( "Upload icon", "factory" ),
                "param_name" => "upload_icon",
                "description" => esc_html__( "upload imag as your wish.", "factory" ),
                "dependency" => array(
                    "element" => "icon_type",
                    "value" => array("1"),
                    )
                ),
                array(
                "type" => "iconpicker",
                "heading" => esc_html__( "Choose icon", "factory" ),
                "param_name" => "choose_icon",
                "description" => esc_html__( "Choose icon.", "factory" ),
                "dependency" => array(
                    "element" => "icon_type",
                    "value" => array("2"),
                    )
                ),
                array(
                    "type" => "attach_image",
                    "heading" => esc_html__( "Box Background", "factory" ),
                    "param_name" => "box_background",
                    "description" => esc_html__( "upload imag as your wish.", "factory" ),
                ),
            )
        )
);

