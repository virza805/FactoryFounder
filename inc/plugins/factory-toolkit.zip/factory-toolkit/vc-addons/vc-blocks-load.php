<?php

//================Vc block load code ==============================
	if( ! defined('ABSPATH' ) ) die('-1');
 	// Class started
 	Class stockVCExtendAddonClass{

 		function __construct(){
 			// we safely integrate with VC with this hook
 			add_action('init', array( $this, 'stockIntegrateWithVC'));
 		}

 		public function stockIntegrateWithVC() {
             // Checks if Visual Composer is not installed
 			if( ! defined( 'WPB_VC_VERSION' ) ){
 				add_action('admin_notices', array( $this, 'stockShowVcVersionNotice' ));
 				return;
             }
             

 			// vissual composer addons
			 include  FACTORY_ACC_PATH . '/vc-addons/vc-logo-carousel.php';
			 
             include  FACTORY_ACC_PATH . '/vc-addons/vc-tile-gallery.php';
			 include  FACTORY_ACC_PATH . '/vc-addons/vc-contact.php';



			 include  FACTORY_ACC_PATH . '/vc-addons/vc-slid.php';
			 include  FACTORY_ACC_PATH . '/vc-addons/vc-s-title.php';
			 include  FACTORY_ACC_PATH . '/vc-addons/vc-servic.php';
			 include  FACTORY_ACC_PATH . '/vc-addons/vc-f-about-tool.php';
			 include  FACTORY_ACC_PATH . '/vc-addons/vc-buttons.php';
			 include  FACTORY_ACC_PATH . '/vc-addons/vc-accordion.php';
			 include  FACTORY_ACC_PATH . '/vc-addons/vc-team.php';
			 include  FACTORY_ACC_PATH . '/vc-addons/vc-cv.php';
			 include  FACTORY_ACC_PATH . '/vc-addons/vc-social-icons.php';
			 include  FACTORY_ACC_PATH . '/vc-addons/vc-counter-up.php';
			 include  FACTORY_ACC_PATH . '/vc-addons/vc-colum-up.php';
			 include  FACTORY_ACC_PATH . '/vc-addons/vc-other-slid.php';
			 include  FACTORY_ACC_PATH . '/vc-addons/vc-blog-count.php';
			 include  FACTORY_ACC_PATH . '/vc-addons/vc-project-count.php';
			 include  FACTORY_ACC_PATH . '/vc-addons/vc-project-slid.php';
			 include  FACTORY_ACC_PATH . '/vc-addons/vc-project-info.php';
			 
			 // Load Stock Default Templates
             include  FACTORY_ACC_PATH . '/vc-addons/vc-templates.php';
             			
 			}

 		// show visual composer version
 		public function stockShowVcVersionNotice() {
 			$theme_data = wp_get_theme();
 			echo '
	 			<div class="notice notice-warning">
				    <p>'.sprintf(__('<strong>%s</strong> recommends <strong><a href="'.site_url().'/wp-admin/themes.php?page=tgmpa-install-plugins" target="_blank">Visual Composer</a></strong> plugin to be installed and activated on your site.', 'strock-crazycafe'), $theme_data->get('Name')).'</p>
				</div>
 			';
 		}
 	}

// Finally initialize code
new stockVCExtendAddonClass();