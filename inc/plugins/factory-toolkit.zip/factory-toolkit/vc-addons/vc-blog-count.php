<?php 
vc_map( 
    array(
  "name" => __( "Show number of Blog", "factory" ),
  "base" => "news-title",
  "category" => __( "Factory", "factory"),
  "params" => array(
	 array(
	  "type" => "textfield",
	  "heading" => __( "Blog Post Count", "factory" ),
	  "param_name" => "count",
	 ),
	

  )
 ) 
 );