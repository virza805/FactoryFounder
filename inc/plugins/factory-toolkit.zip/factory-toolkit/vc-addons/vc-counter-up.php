<?php 

vc_map(
    array(
     "name" => __( "Counter-Up for Factory", "factory" ),
     "base" => "counter_up",
     "category" => __( "Factory", "factory"),
     "params" => array(
         
         
        
        
        
        
        

        // Social icon & link.. Start Now ... ..
         array(
           'type' => 'param_group',
           'param_name' => 'counter_up_group',
           // Note params is mapped inside param-group:
           'params' => array(
            
                
                array(
                    "type" => "textfield",
                    "heading" => __( "Count Number", "factory" ),
                    "param_name" => "head",
                    "std" => esc_html__( "100", "factory" ),
                ),
                array(
                    "type" => "textarea",
                    "heading" => __( "Count Name", "factory" ),
                    "param_name" => "des",
                    "std" => esc_html__( "Enter your Count-Name", "factory" ),
                ),
                array(
                "type" => "iconpicker",
                "heading" => esc_html__( "Choose icon", "factory" ),
                "param_name" => "choose_icon",
                "description" => esc_html__( "Choose icon.", "factory" ),
                ),
                array(
                "type" => "textfield",
                "heading" => esc_html__( "Count time by secound", "factory" ),
                "param_name" => "s_external_link",
                "description" => esc_html__( "Enter Count time only seciend value ..", "factory" ),
                
                "std" => esc_html__( "3000", "factory" ),
                ),
            


           )
         )
       
       )
   )
);