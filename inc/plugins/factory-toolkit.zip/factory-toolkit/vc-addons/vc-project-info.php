<?php 

vc_map(
    array(
     "name" => __( "Factory Project Info.", "factory" ),
     "base" => "info",
     "category" => __( "Factory", "factory"),
     "params" => array(
         
         
        array(
            "type" => "textfield",
            "heading" => __( "Heading", "factory" ),
            "param_name" => "title",
            "std" => esc_html__( "Latest project information", "factory" ),
        ),
        
        
        
        
        

        // Social icon & link.. Start Now ... ..
         array(
           'type' => 'param_group',
           'param_name' => 'info_group',
           // Note params is mapped inside param-group:
           'params' => array(
            
                
                array(
                    "type" => "textfield",
                    "heading" => __( "Heading", "factory" ),
                    "param_name" => "head",
                    "std" => esc_html__( "  ", "factory" ),
                ),
                array(
                    "type" => "textarea",
                    "heading" => __( "Description", "factory" ),
                    "param_name" => "des",
                    "std" => esc_html__( "Enter your Description", "factory" ),
                ),
                array(
                "type" => "iconpicker",
                "heading" => esc_html__( "Choose icon", "factory" ),
                "param_name" => "choose_icon",
                "description" => esc_html__( "Choose Social icon.", "factory" ),
                ),
                array(
                "type" => "textfield",
                "heading" => esc_html__( "Icon Link text", "factory" ),
                "param_name" => "s_external_link",
                "description" => esc_html__( "Enter Your Social Link Text ..", "factory" )
                ),
            


           )
         )
       
       )
   )
);