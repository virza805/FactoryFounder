<?php 

vc_map(
    array(
     "name" => __( "Progress-levels", "factory" ),
     "base" => "colum_up",
     "category" => __( "Factory", "factory"),
     "params" => array(
         
         
        
        
        
        
        

        // Social icon & link.. Start Now ... ..
         array(
           'type' => 'param_group',
           'param_name' => 'colum_up_group',
           // Note params is mapped inside param-group:
           'params' => array(
            
                
                array(
                    "type" => "textfield",
                    "heading" => __( "Progress Number", "factory" ),
                    "param_name" => "head",
                    "std" => esc_html__( "100", "factory" ),
                ),
                array(
                    "type" => "textarea",
                    "heading" => __( "Progress Name", "factory" ),
                    "param_name" => "des",
                    "std" => esc_html__( "Enter your Progress-Name", "factory" ),
                ),
                
                array(
                "type" => "textfield",
                "heading" => esc_html__( "Progress time by secound", "factory" ),
                "param_name" => "s_external_link",
                "description" => esc_html__( "Enter Progress time only mili-seciend value ..", "factory" ),
                
                "std" => esc_html__( "1500", "factory" ),
                ),
            


           )
         )
       
       )
   )
);