<?php 

vc_map(
    array(
     "name" => __( "Other Slider", "factory" ),
     "base" => "other_slid",
     "category" => __( "Factory", "factory"),
     "params" => array(
         
        
        array(
            "type" => "attach_image",
            "heading" => esc_html__( "Slider back ground image", "factory" ),
            "param_name" => "s_bg_img",
            "description" => esc_html__( "upload Your bg img.", "factory" )
            ),
        array(
            "type" => "dropdown",
            "heading" => esc_html__( "Factory Service Details other_slid", "factory" ),
            "param_name" => "other_slid_style",
            "std" => esc_html__( "1", "factory" ),
            "value" => array(
                esc_html__('Review Slider', 'factory-founder') => 1,
                esc_html__('Testimonial Slider', 'factory-founder') => 2,
                ),
            "description" => esc_html__( "Select other_slid Style.", "factory" )
        ),
        array(
        "type" => "textfield",
        "heading" => esc_html__( "Short Description about Review", "factory" ),
        "param_name" => "description",
        "std" => esc_html__( "What People Say About Us", "factory" ),
        "description" => esc_html__( "Description About Membar", "factory" ),
        "dependency" => array(
            "element" => "other_slid_style",
            "value" => array("2"),
            )
        ),
        
        

        // Social icon & link.. Start Now ... ..
         array(
           'type' => 'param_group',
           'param_name' => 'other_slid_group',
           // Note params is mapped inside param-group:
           'params' => array(
            
                
                array(
                    "type" => "textfield",
                    "heading" => __( "Name", "factory" ),
                    "param_name" => "head",
                    "std" => esc_html__( "Tanvir Hasan", "factory" ),
                ),
                
                array(
                    "type" => "textfield",
                    "heading" => __( "title", "factory" ),
                    "param_name" => "title",
                    "std" => esc_html__( "Developer", "factory" ),
                ),
                array(
                    "type" => "textarea",
                    "heading" => __( "description", "factory" ),
                    "param_name" => "des",
                    "std" => esc_html__( "Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu <br>
                    feugiat nulla facilisis at vero. Duis autem vel eum iriure dolor in hendrerit in vulputate velit sse molestie consequatvelillum<br> dolore. eu feugiat nulla molestie consequat, vel illum facilisis at vero.", "factory" ),
                ),
                
                array(
                    "type" => "attach_image",
                    "heading" => esc_html__( "Author image", "factory" ),
                    "param_name" => "author_img",
                    "description" => esc_html__( "upload author img.", "factory" )
                ),
            


           )
         )
       
       )
   )
);