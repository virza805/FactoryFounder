<?php 
vc_map( 
    array(
  "name" => __( "Project Slid", "factory" ),
  "base" => "project_slid",
  "category" => __( "Factory", "factory"),
  "params" => array(
	 array(
	  "type" => "textfield",
	  "heading" => __( "Enter minimum value 5", "factory" ),
      "param_name" => "count",
      "description" => esc_html__( "If you wont to slide you must be input number up to 5", "factory" ),
      "std" => esc_html__( "5", "factory" ),
	 ),
	

  )
 ) 
 );