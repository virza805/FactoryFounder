<?php 

vc_map(
    array(
     "name" => __( "Button", "factory" ),
     "base" => "btn",
     "category" => __( "Factory", "factory"),
     "params" => array(
         array(
           'type' => 'param_group',
           'param_name' => 'btn_group',
           // Note params is mapped inside param-group:
           'params' => array(

                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Factory About Tool Style", "factory" ),
                "param_name" => "btn_style",
                "std" => esc_html__( "1", "factory" ),
                "value" => array(
                    esc_html__('Fill-Color Button', 'factory-founder') => 1,
                    esc_html__('Border-Color Button', 'factory-founder') => 2,
                    esc_html__('Fill-Color without Button', 'factory-founder') => 3,
                    esc_html__('Black-Color without Button', 'factory-founder') => 4,
                    ),
                "description" => esc_html__( "Select Service Style.", "factory" )
                ),
                
                array(
                "type" => "textfield",
                "heading" => __( "Battun", "factory" ),
                "param_name" => "btn",
                "std" => esc_html__( "Purses now", "factory" ),
                ),


                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Button Link type", "factory" ),
                "param_name" => "type",
                "std" => esc_html__( "1", "factory" ),
                "value" => array(
                    esc_html__('Link to page', 'factory-founder') => 1,
                    esc_html__('External link', 'factory-founder') => 2,
                    ),
                "description" => esc_html__( "Select Button Link.", "factory" )
                ),
                array(
                "type" => "dropdown",
                "heading" => esc_html__( "Link to page", "factory" ),
                "param_name" => "link_to_page",
                "value" => factory_get_page_as_list(),
                "description" => esc_html__( "Select Link.", "factory" ),
                "dependency" => array(
                    "element" => "type",
                    "value" => array("1"),
                    )
                ),
                array(
                "type" => "textfield",
                "heading" => esc_html__( "External link", "factory" ),
                "param_name" => "external_link",
                "description" => esc_html__( "Wright external Link.", "factory" ),
                "dependency" => array(
                    "element" => "type",
                    "value" => array("2"),
                    )
                ),

                
                

// End Group
       
           )
         )
       
       )
   )
);