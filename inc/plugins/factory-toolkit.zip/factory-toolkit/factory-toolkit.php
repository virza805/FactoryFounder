<?php 
/*
Plugin Name: Factory Founder
Plugin URI: http://vir-za.com/
Description: This is helper plugin for "Factory Founder" WordPress theme.
Version: 1.0.1
Author: Tanvir Hasan
Author URI: https://vir-za.com/
License: 564.505
Text Domain: factory-founder
*/
// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
// Define
define( 'FACTORY_ACC_URL', WP_PLUGIN_URL . '/' . plugin_basename( dirname( __FILE__ ) ) . '/' );
define( 'FACTORY_ACC_PATH', plugin_dir_path( __FILE__ ) );

// How to SlidePost according to list-style...function
// function stock_toolkit_get_slide_as_list() {
//     $args = wp_parse_args( array(
//         'post_type' => 'slide',
//         'numberposts' => -1,
//     ));

//     $posts = get_posts( $args );

//     $post_options = array(esc_html__('-- Select Slide --', 'factory-founder')=> '');
//     if( $posts ){
//         foreach ( $posts as $post ) {
//             $post_options[ $post->post_title ] = $post->ID;
//         }
//     }
//     return $post_options;
// } 
// How to Page according to list-style...function
function factory_get_page_as_list() {
    $args = wp_parse_args( array(
        'post_type' => 'page',
        'numberposts' => -1,
    ));

    $posts = get_posts( $args );

    $post_options = array(esc_html__('-- Select Page --', 'factory-founder')=> '');
    if( $posts ){
        foreach ( $posts as $post ) {
            $post_options[ $post->post_title ] = $post->ID;
        }
    }
    return $post_options;
} 
 // ######## >>>> Custom Post Register <<<< ########
add_action( 'init', 'stock_toolkit_custom_post' );
function stock_toolkit_custom_post() {
//     // For Slider
//     register_post_type( 'slide',
//     array(
//         'labels' => array(
//             'name' => esc_html__('Slides', 'factory-founder'),
//             'singular_name' => esc_html__('Slide', 'factory-founder')
//         ),
//         'supports' => array('title', 'editor', 'thumbnail', 'page-attributes'),
//         'public' => false,
//         'show_ui' => true,
//         )
//     );

    // For OurWork/Project
    register_post_type( 'project',
    array(
        'labels' => array(
            'name' => __('Projects'),
            'singular_name' => __('Project')
        ),
        'supports' => array('title', 'editor', 'thumbnail', 'page-attributes'),
        'public' => true,
        )
    );
}

// ######## >>>> Custom Post-taxonomy Register <<<< ########
function stock_toolkit_custom_post_taxonomy() {
    register_taxonomy(
        'project_cat',  
        'project',                  
        array(
            'hierarchical'          => true,
            'label'                 => 'Project Category',  
            'query_var'             => true,
            'show_admin_column'     => true,
            'rewrite'               => array(
                'slug'              => 'project-category', 
                'with_front'    => true 
                )
            )
    );
}
add_action( 'init', 'stock_toolkit_custom_post_taxonomy');



// print shortcodes in widgets
add_filter('widget_text', 'do_shortcode');

// Loading VC addons
 require_once( FACTORY_ACC_PATH . 'vc-addons/vc-blocks-load.php' );


// Theme ShortCodes
 require_once( FACTORY_ACC_PATH . 'theme-shortcodes/logo-carousel-shortcode.php' );
 
 require_once( FACTORY_ACC_PATH . 'theme-shortcodes/tile-gallery-shortcode.php' );
 require_once( FACTORY_ACC_PATH . 'theme-shortcodes/contact-shortcode.php' );


 require_once( FACTORY_ACC_PATH . 'theme-shortcodes/slid.php' );
 require_once( FACTORY_ACC_PATH . 'theme-shortcodes/s-title-shortcode.php' );
 require_once( FACTORY_ACC_PATH . 'theme-shortcodes/servic-shortcode.php' );
 require_once( FACTORY_ACC_PATH . 'theme-shortcodes/f-about-tool-shortcode.php' );
 require_once( FACTORY_ACC_PATH . 'theme-shortcodes/buttons-shortcode.php' );
 require_once( FACTORY_ACC_PATH . 'theme-shortcodes/accordion-shortcode.php' );
 require_once( FACTORY_ACC_PATH . 'theme-shortcodes/team-shortcode.php' );
 require_once( FACTORY_ACC_PATH . 'theme-shortcodes/cv-shortcode.php' );
 require_once( FACTORY_ACC_PATH . 'theme-shortcodes/social-icons-shortcode.php' );
 require_once( FACTORY_ACC_PATH . 'theme-shortcodes/counter-up-shortcode.php' );
 require_once( FACTORY_ACC_PATH . 'theme-shortcodes/colum-up-shortcode.php' );
 require_once( FACTORY_ACC_PATH . 'theme-shortcodes/other-slid-shortcode.php' );
 require_once( FACTORY_ACC_PATH . 'theme-shortcodes/blog-count-shortcode.php' );
 require_once( FACTORY_ACC_PATH . 'theme-shortcodes/project-count-shortcode.php' );
 require_once( FACTORY_ACC_PATH . 'theme-shortcodes/project-slid-shortcode.php' );
 require_once( FACTORY_ACC_PATH . 'theme-shortcodes/project-info-shortcode.php' );

// Shortcodes depended on Visual Composer
include_once( ABSPATH .'wp-admin/includes/plugin.php' );
if (is_plugin_active('js_composer/js_composer.php')) {
    // require_once( FACTORY_ACC_PATH . 'theme-shortcodes/staff-shortcode.php' );
}

// Registering stock toolkit files
function factory_toolkit_files() {

    wp_enqueue_style('owl-carousel', plugin_dir_url(__FILE__) . 'assets/css/owl.carousel.css');
    wp_enqueue_style('factory-founder', plugin_dir_url(__FILE__) . 'assets/css/factory-toolkit.css');
    wp_enqueue_script('owl-carousel', plugin_dir_url(__FILE__) . 'assets/js/owl.carousel.min.js', array('jquery'), '20120206', true );

    wp_enqueue_script('gmap3', plugin_dir_url(__FILE__) . 'assets/js/gmap3.min.js', array('jquery'), '20120206', true );
}
add_action('wp_enqueue_scripts', 'factory_toolkit_files');




?>