<?php 

function stock_tile_gallery_shortcode($atts, $content = null) {
    extract( shortcode_atts( array(
        'images' => '',
        'height' => '310',
        'size' => 'lage',
    ), $atts));

    $image_ids = explode(',', $images);
    $image_count = count($image_ids);
    $imag_no = 0;

   if(!empty($images)) {
    $stock_tile_gallery_markup = '
    <div class="stock-tile-gallery stock-tile-gallery-image-'.$image_count.'">';

        foreach($image_ids as $image) {
            $image_array = wp_get_attachment_image_src($image, $size);
            $imag_no++;
            $stock_tile_gallery_markup .= '<div style="background-image:url('.esc_url($image_array[0]).');height:'.esc_attr($height).'px" class="tile-gallery-block tile-gallery-block-'.$imag_no.'"></div>';
        }
        
        $stock_tile_gallery_markup .= '
    </div>
    ';
   }else{
    $stock_tile_gallery_markup = '';
   }

    return $stock_tile_gallery_markup;


}
add_shortcode('stock_tile_gallery', 'stock_tile_gallery_shortcode');
