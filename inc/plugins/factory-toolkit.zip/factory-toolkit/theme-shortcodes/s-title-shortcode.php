<?php 
add_shortcode('title-section','title_section_func');
function title_section_func($jekono){
	$result = shortcode_atts(array(
		'sec_tit' =>'',
		'sec_des' =>'',
	),$jekono);

	extract($result);


	ob_start();
    ?>
    
    <div class="service-title-2">
        <h2><?php echo $sec_tit; ?></h2>
        <p><span class="border_dot"></span><?php echo $sec_des; ?><span class="border_dot_right"></span></p>
    </div>


	<?php
	return ob_get_clean();
}

// add_action( 'vc_before_init', 'title_section_el' );
// function title_section_el() {
 
// }
//  ?>