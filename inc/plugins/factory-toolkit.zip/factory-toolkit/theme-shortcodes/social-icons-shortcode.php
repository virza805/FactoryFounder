<?php 
add_shortcode('social','social_section_func');
function social_section_func($jekono){
	$result = shortcode_atts(array(
		'social_group' =>'',
        
		
	),$jekono);

	extract($result);

	ob_start();



	?>

<?php


echo '

<div class="social-link social-icon text-center">
    <ul>';

        $testimonials = vc_param_group_parse_atts($social_group);
            foreach ($testimonials as $item): 
        echo '<li><a href="'.esc_url($s_external_link).'"><i class="'.esc_attr($item['choose_icon']).'" aria-hidden="true"></i></a></li>';
                        
            endforeach; 

        echo '
    </ul>
</div>
 
';

?>
           
	<?php
	return ob_get_clean();

}
