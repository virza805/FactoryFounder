<?php 
add_shortcode('team','team_section_func');
function team_section_func($jekono){
	$result = shortcode_atts(array(
		'team_group' =>'',
        'team_style' => 1,
        
        'head' => '',
        'des' => '',
        'description' => '',
        'type' => 1,
        'link_to_page' => '',
        'external_link' => '',
        'link_text' => 'See more',
        // 'service_style' => 1,
        // 'icon_type' => 1,
        // 'upload_icon' => '',
        'choose_icon' => '',
        'upload_profile_img' => '',
		
	),$jekono);

	extract($result);

	ob_start();



	?>

<?php

// For Source link
if($type == 1){
    $link_source = get_page_link($link_to_page);
}else{
    $link_source = $external_link;
}

// For desc Or Paragraph
$description_allowed_tags = array(
    'a' => array(
        'href' => array(),
        'title' => array(),
        'class' => array()
    ),
    'img' => array(
        'alt' => array(),
        'src' => array()
    ),
    'br' => array(),
    'em' => array(),
    'strong' => array(),
);

if($team_style == 1) {

$upload_profile_img_array = wp_get_attachment_image_src($upload_profile_img, 'large');

echo '
<section class="team-section">
    <div class="container">
        <div class="row">
<!--Start single  item-->
<div class="col-md-12 col-sm-12 col-xs-12 ">
    <div class="team-mamber item-margin-bot-60 rsp-pdd">
        <div class="team-image">
            <img src="'.esc_url($upload_profile_img_array[0]).'" alt="">
        </div>
        <div class="team-content">
            <div class="team-text">
                <a href="'.esc_url($link_source).'"><h2>'.esc_html($head).'</h2></a>
                <h6>'.esc_html($des).'</h6>
                <p>'.wp_kses(wpautop($description), $description_allowed_tags).'</p>
            </div>
                <div class="social-link">
                    <ul>';

                    $testimonials = vc_param_group_parse_atts($team_group);
                    foreach ($testimonials as $item): 
                        echo '<li><a href="'.esc_url($s_external_link).'"><i class="'.esc_attr($item['choose_icon']).'" aria-hidden="true"></i></a></li>';
                        
                    endforeach; 

                echo ' </ul>
                </div>
            <div class="team-button"><a href="'.esc_url($link_source).'" class="theme-btn skew-btn"><span class="btn-text">'.esc_html($link_text).'</span></a></div>
        </div>
    </div>
</div>
<!--End single  item-->


        </div>
    </div>
</section>
';

} else {

$upload_profile_imgs = wp_get_attachment_image_src($upload_profile_img, 'large');

echo '
<section class="team-section-2">
    <div class="container">
        <div class="row">
    <!-- Startsingle-team-member -->
    <div class="col-md-12 col-sm-12 col-xs-12 ">
        <div class="single-team-member itm-mgn-bot">
            <div class="img-holder text-center">
                <img src="'.esc_url($upload_profile_imgs[0]).'" alt="" class="person-image">
                <div class="social-icons">
                    <ul class="list-inline">';

                    $testimonials = vc_param_group_parse_atts($team_group);
                    foreach ($testimonials as $item): 
                        echo '<li><a href="'.esc_url($s_external_link).'"><i class="'.esc_attr($item['choose_icon']).'" aria-hidden="true"></i></a></li>';
                        
                    endforeach; 

                echo '</ul>
                </div>
            </div>
            <a href="'.esc_url($link_source).'" class="content">
                <h3 class="">'.esc_html($head).'</h3>
                <span>'.esc_html($des).'</span>
            </a>
        </div> 
    </div>
    <!-- End single-team-member -->
        </div>
    </div>
</section>

';


} ?>

                    
	<?php
	return ob_get_clean();

}
