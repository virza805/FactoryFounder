<?php 

add_shortcode('factory_f_a_tool', 'factory_f_a_tool_shortcode');
function factory_f_a_tool_shortcode($atts, $content = null) {

    extract( shortcode_atts( array(
        'title' => '',
        'desc' => '',
        'type' => 1,
        'link_to_page' => '',
        'external_link' => '',
        'f_a_style' => 1,
        'link_text' => 'See more',
        'icon_type' => 1,
        'upload_icon' => '',
        'choose_icon' => '',
        'box_background' => '',


        'title_b' => '',
        'desc_b' => '',
        'type_b' => 1,
        'link_to_page_b' => '',
        'external_link_b' => '',
        'f_a_style_b' => 1,
        'link_text_b' => 'See more',
        'icon_type_b' => 1,
        'upload_icon_b' => '',
        'choose_icon_b' => '',
        'box_background_b' => '',
    ), $atts));

    ob_start();
?>
<?php 

$stock_cta_desc_allowed_tags = array(
    'a' => array(
        'href' => array(),
        'title' => array(),
        'class' => array()
    ),
    'img' => array(
        'alt' => array(),
        'src' => array()
    ),
    'br' => array(),
    'em' => array(),
    'strong' => array(),
);
if($f_a_style == 1) {
    echo '
<div class="row">
<div class="col-md-6 vir col-sm-6 col-xs-12">
    <div class="about-content item-margin-bot-30">
        <div class="icon-box">
        ';
                if($icon_type == 1){
$service_icon_array = wp_get_attachment_image_src($upload_icon, 'thumbnail');
            echo '<img src="'.esc_url($service_icon_array[0]).'" alt=""/>';
            }else{
            echo '<i class="'.esc_attr($choose_icon).'"></i>';
            }

            echo '
            </div>
            <div class="box-content">
                <h4>'.esc_html($title).'</h4>
                <p>'.wp_kses(wpautop($desc), $stock_cta_desc_allowed_tags).'</p>
            </div>
    </div>
</div>
<div class="col-md-6 vir col-sm-6 col-xs-12">
    <div class="about-content item-margin-bot-30">
        <div class="icon-box">
        ';
                if($icon_type_b == 1){
$service_icon_array = wp_get_attachment_image_src($upload_icon_b, 'thumbnail');
            echo '<img src="'.esc_url($service_icon_array[0]).'" alt=""/>';
            }else{
            echo '<i class="'.esc_attr($choose_icon_b).'"></i>';
            }

            echo '
            </div>
            <div class="box-content">
                <h4>'.esc_html($title_b).'</h4>
                <p>'.wp_kses(wpautop($desc_b), $stock_cta_desc_allowed_tags).'</p>
            </div>
    </div>
</div>
</div>
    ';


}elseif($f_a_style == 2){


    echo '
<div class="row">
<div class="col-md-6 vir col-sm-6 col-xs-12">
    <div class="about-content item-margin-bot-20">
        <div class="icon-box">
        ';
        if($icon_type == 1){
$service_icon_array = wp_get_attachment_image_src($upload_icon, 'thumbnail');
    echo '<img src="'.esc_url($service_icon_array[0]).'" alt=""/>';
    }else{
    echo '<i class="'.esc_attr($choose_icon).'"></i>';
    }

    echo '
        </div>
        <div class="box-content">
            <h4 class="bk">'.esc_html($title).'</h4>
            <p>'.wp_kses(wpautop($desc), $stock_cta_desc_allowed_tags).'</p>
        </div>
    </div>
</div>
<div class="col-md-6 vir col-sm-6 col-xs-12">
    <div class="about-content item-margin-bot-20">
        <div class="icon-box">
        ';
        if($icon_type_b == 1){
$service_icon_array = wp_get_attachment_image_src($upload_icon_b, 'thumbnail');
    echo '<img src="'.esc_url($service_icon_array[0]).'" alt=""/>';
    }else{
    echo '<i class="'.esc_attr($choose_icon_b).'"></i>';
    }

    echo '
        </div>
        <div class="box-content">
            <h4 class="bk">'.esc_html($title_b).'</h4>
            <p>'.wp_kses(wpautop($desc_b), $stock_cta_desc_allowed_tags).'</p>
        </div>
    </div>
</div>
</div>
    ';
}else{
    echo '
<div class="container">
    <div class="default-icon-box">
            <div class="icon">
            ';
                    if($icon_type == 1){
            $service_icon_array = wp_get_attachment_image_src($upload_icon, 'thumbnail');
                echo '<img src="'.esc_url($service_icon_array[0]).'" alt=""/>';
                }else{
                echo '<i class="'.esc_attr($choose_icon).'"></i>';
                }

                echo '
            </div>
        <div class="content-text">
            <h2>'.esc_html($title).'</h2>
            <p>'.wp_kses(wpautop($desc), $stock_cta_desc_allowed_tags).'</p>
        </div>
    </div>
</div>
    ';
}

?>


<?php
	return ob_get_clean();
}

