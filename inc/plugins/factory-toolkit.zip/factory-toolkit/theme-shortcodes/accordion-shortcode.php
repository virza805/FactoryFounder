<?php 
add_shortcode('accordion','accordion_section_func');
function accordion_section_func($jekono){
	$result = shortcode_atts(array(
		'accordion_group' =>'',
        'accordion_style' => 1,
		
	),$jekono);

	extract($result);

	ob_start();



	?>

<?php if($accordion_style == 1) {
    echo '<div class="accordion-box">';
    $testimonials = vc_param_group_parse_atts($accordion_group);
            foreach ($testimonials as $item): ?>  
            <div class="accordion animated out" data-delay="0" data-animation="fadeInUp">
            <div class="acc-btn accordion_border">
                <?php echo $item['head'] ?>
                <div class="toggle-icon skew-btn">
                    <span class="plus fa fa-plus"></span><span class="minus fa fa-minus"></span>
                </div>
            </div>
            <div class="acc-content">
                <p><?php echo $item['des'] ?></p>
            </div>
        </div>
        
    <?php endforeach; 
    echo '</div>';
} else {
    echo '<div class="accordion-box sm-margin-bot style-two">';
    $testimonials = vc_param_group_parse_atts($accordion_group);
            foreach ($testimonials as $item): ?>  
        <div class="accordion accordion-block">
            <div class="accord-btn"><h4><?php echo $item['head'] ?></h4></div>
            <div class="accord-content">
                    <p><?php echo $item['des'] ?></p>
            </div>
        </div>
        
    <?php endforeach; 
    echo '</div>';
} ?>

<!--Start accordion box-->

<!--End accordion box-->

                    
	<?php
	return ob_get_clean();

}
