<?php 
add_shortcode('project','project_section_func');
function project_section_func($jekono){
	$result = shortcode_atts(array(
		'count' =>'',
		
	),$jekono);

	extract($result);

	ob_start(); 
	?>

<!--Start blog-content area-->
        <section class="inner-project sec-pdd-90">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12 ">
                        <!-- Start single-item -->
                        <?php 
        				$q = new WP_Query(array(
        					'post_type' => 'project',
        					'posts_per_page' => $count,

        				));
        				while($q->have_posts()):$q->the_post();
        			 ?>
                        <div class="single-project item-margin-bot-50">
                            <div class="event_img_holder">
                                <?php  echo  the_post_thumbnail();?> 
                                
                            </div>
                            <div class="project-content">
                                <a href="<?php the_permalink();?>"><h4><?php  echo the_title();?></h4></a>
                                <div class="icon_text_box">
                                    <h5><?php echo the_time('d M Y')?></h5>
                                    <h5>post : <?php  echo the_author();?></h5>
                                    <p><?php echo 
                                        wp_trim_words(get_the_content(),'25','');
                                    ?> <a href="<?php the_permalink();?>"><?php echo esc_html('Read More');?></a></p>
                                </div>
                            </div>
                        </div>
                        <!-- End single-item -->
                        <?php endwhile;?>
                        
        <div class="col-md-12">
            <div class="row justify-content-center">
                <div class="col-md-8 text-center">
                    <?php 
                    $pagination= get_the_posts_pagination(
                        array(
                        'show_all'=> false,
                        
                        'prev_text'=>__('<i class="fa fa-angle-left" aria-hidden="true"></i>', 'factory-founder'),
                        'next_text'=>__('<i class="fa fa-angle-right sm-margin-bot" aria-hidden="true"></i>','factory-founder'),
                            )
                        );

                    $pagination = str_replace('navigation pagination', 'page_list', $pagination);
                    $pagination = str_replace('nav-links', 'list_icon', $pagination);
                
                    $pagination =str_replace('current', 'active-post', $pagination);
                    $pagination =str_replace('span', 'a', $pagination);

                    echo $pagination;       
			        ?>
            
                </div>
            </div>
        </div>


                        

                        <div class="page_list">
                            <a href="#"><i class="fa fa-angle-left" aria-hidden="true"></i></a>
                            <ul class="list_icon">
                                <li><a href="#">1</a></li>
                                <li><a href="#">2</a></li>
                                <li><a href="#">3</a></li>
                            </ul>
                            <a href="#"> <i class="fa fa-angle-right sm-margin-bot" aria-hidden="true"></i></a>
                        </div>
                    </div>
                    
                </div> 
            </div>
        </section>       
        <!--End blog-content area-->

	<?php
	return ob_get_clean();
}

 ?>