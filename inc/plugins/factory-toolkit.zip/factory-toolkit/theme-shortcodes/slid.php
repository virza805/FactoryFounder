<?php 
add_shortcode('slider','slider_section_func');
function slider_section_func($jekono){
	$result = shortcode_atts(array(
		'slider_group' =>'',
		
	),$jekono);

	extract($result);

	ob_start();



	?>

<!--Start slider-->     
<section class="home-section">
    
<?php
$enable_s_preloader = cs_get_option('enable_s_preloader'); 

if($enable_s_preloader == true) : ?>
    <script>
            jQuery(window).load(function(){
                jQuery(".preloader-wrap").fadeOut();

            });
    </script>

    <div class="preloader-wrap">
		<div class="s-loader">Loading...</div>
    </div>
<?php endif; ?>
            <div id="slider1" class="rev_slider"  data-version="5.0">
                <ul>
                <?php 
                  $testimonials = vc_param_group_parse_atts($slider_group);
                  foreach ($testimonials as $item):
                    $image_src = wp_get_attachment_url($item['image']);
                ?>
                    <li data-transition="fade">
                        <img src="<?php echo $image_src; ?>"  alt="" width="1920" height="1020" data-bgposition="top center" data-bgfit="cover" data-bgrepeat="no-repeat" data-bgparallax="1" >
                        
                        <div class="tp-caption tp-resizeme factory-founder"
                            data-x="left" data-hoffset="0" 
                            data-y="top" data-voffset="200" 
                            data-transform_idle="o:1;"         
                            data-transform_in="x:[-175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0.01;s:3000;e:Power3.easeOut;" 
                            data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" 
                            data-mask_in="x:[100%];y:0;s:inherit;e:inherit;" 
                            data-splitin="none" 
                            data-splitout="none"  
                            data-start="500">
                            <h2><?php echo $item['shead'] ?></h2>
                        </div>
                        <div class="tp-caption tp-resizeme factory-founder"
                            data-x="left" data-hoffset="0" 
                            data-y="top" data-voffset="238"  
                            data-transform_idle="o:1;"                         
                            data-transform_in="x:[175%];y:0px;z:0;rX:0;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0.01;s:3000;e:Power3.easeOut;" 
                            data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;" 
                            data-mask_in="x:[-100%];y:0;s:inherit;e:inherit;" 
                            data-splitin="none" 
                            data-splitout="none" 
                            data-responsive_offset="on"
                            data-start="1500">
                            <h4><?php echo $item['head'] ?></h4>
                            <div class="border"></div>
                        </div>
                        <div class="tp-caption tp-resizeme factory-founder" 
                            data-x="left" data-hoffset="0" 
                            data-y="top" data-voffset="360"  
                            data-transform_idle="o:1;"                         
                            data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                            data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"                     
                            data-splitin="none" 
                            data-splitout="none" 
                            data-responsive_offset="on"
                            data-start="2000">
                            <p><?php echo $item['des'] ?></p>
                        </div>
                        <div class="tp-caption tp-resizeme factory-founder" 
                            data-x="left" data-hoffset="0" 
                            data-y="top" data-voffset="465"  
                            data-transform_idle="o:1;"                         
                            data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                            data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"                     
                            data-splitin="none" 
                            data-splitout="none" 
                            data-responsive_offset="on"
                            data-start="3000">
                            <div>
                            <?php 
    if($type == 1){
        $link_source = get_page_link($item['link_to_page']);
    }else{
        $link_source = $item['external_link'];
    } 
    ?>
                                <a class="button-1" href="<?php echo esc_url($link_source); ?>"><?php echo $item['btn'] ?></a>
                            </div>
                        </div>
                        <div class="tp-caption tp-resizeme factory-founder" 
                            data-x="left" data-hoffset="165" 
                            data-y="top" data-voffset="465"  
                            data-transform_idle="o:1;"                         
                            data-transform_in="y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;opacity:0;s:2000;e:Power4.easeInOut;" 
                            data-transform_out="s:1000;e:Power3.easeInOut;s:1000;e:Power3.easeInOut;"                     
                            data-splitin="none" 
                            data-splitout="none" 
                            data-responsive_offset="on"
                            data-start="3000">
                            <div>
                            <?php 
    if($typ == 1){
        $link_sourc = get_page_link($item['link_to_pag']);
    }else{
        $link_sourc = $item['external_lin'];
    } 
    ?>
                                <a class="button-2" href="<?php echo esc_url($link_sourc); ?>"><?php echo $item['btnr'] ?></a>
                            </div>
                        </div>
                    </li>

            <?php endforeach; ?>   
                    
                </ul>
            </div>
        </section>
        <!--End slider -->
                    
	<?php
	return ob_get_clean();

}
