<?php 
add_shortcode('cv','cv_section_func');
function cv_section_func($jekono){
	$result = shortcode_atts(array(
		'cv_group' =>'',
        
        'head' => '',
        'des' => '',
        'type' => 1,
        'link_to_page' => '',
        'external_link' => '',
        // 'service_style' => 1,
        // 'icon_type' => 1,
        // 'upload_icon' => '',
        'choose_icon' => '',
        'upload_profile_img' => '',
		
	),$jekono);

	extract($result);

	ob_start();



	?>

<?php

// For desc Or Paragraph
$des_allowed_tags = array(
    'a' => array(
        'href' => array(),
        'title' => array(),
        'class' => array()
    ),
    'img' => array(
        'alt' => array(),
        'src' => array()
    ),
    'br' => array(),
    'em' => array(),
    'strong' => array(),
);

?>

    <table class="table table-borderless engineers-detail ">
        
        <tbody>
        <?php $testimonials = vc_param_group_parse_atts($cv_group);
                    foreach ($testimonials as $item): ?>
            <tr>
                <th><?php echo esc_html($item['head']) ?></th>
                <td>
                <a href="<?php echo esc_url($item['s_external_link']) ?>">
                <i class="<?php echo esc_attr($item['choose_icon']) ?>"></i></a><?php echo wp_kses(wpautop($item['des']), $des_allowed_tags) ?><br>
                


                


                </td>
            </tr>
        <?php endforeach; ?>
                       
        </tbody>
    </table>
     
	<?php
	return ob_get_clean();

}
