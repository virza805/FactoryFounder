<?php 
add_shortcode('info','info_section_func');
function info_section_func($jekono){
	$result = shortcode_atts(array(
		'info_group' =>'',
        
        'title' => '',
        'head' => '',
        'des' => '',
        'type' => 1,
        'link_to_page' => '',
        'external_link' => '',
        // 'service_style' => 1,
        // 'icon_type' => 1,
        // 'upload_icon' => '',
        'choose_icon' => '',
        'upload_profile_img' => '',
		
	),$jekono);

	extract($result);

	ob_start();



	?>

<?php

// For desc Or Paragraph
$des_allowed_tags = array(
    'a' => array(
        'href' => array(),
        'title' => array(),
        'class' => array()
    ),
    'img' => array(
        'alt' => array(),
        'src' => array()
    ),
    'br' => array(),
    'em' => array(),
    'strong' => array(),
);

?>
<div class="side_bar">
        <!--Start single  item-->
    <div class="project-info">
        <h4><?php echo esc_html($title) ?> </h4>
        <?php $testimonials = vc_param_group_parse_atts($info_group);
                    foreach ($testimonials as $item): ?>
        <div class="short-info">
            <i class="<?php echo esc_attr($item['choose_icon']) ?>"></i>
            <a href="<?php echo esc_url($item['s_external_link']) ?>"><span><?php echo esc_html($item['head']) ?> </span><?php echo wp_kses(wpautop($item['des']), $des_allowed_tags) ?></a>
        </div>
        <?php endforeach; ?>
                                
    </div>
</div>

     
	<?php
	return ob_get_clean();

}
