<?php 
add_shortcode('colum_up','colum_up_section_func');
function colum_up_section_func($jekono){
	$result = shortcode_atts(array(
		'colum_up_group' =>'',
        
        'head' => '',
        'des' => '',
        'type' => 1,
        'link_to_page' => '',
        'external_link' => '',
        // 'service_style' => 1,
        'icon_type' => 1,
        'upload_icon' => '',
        'choose_icon' => '',
        'upload_profile_img' => '',
		
	),$jekono);

	extract($result);

	ob_start();



	?>

<?php

// For desc Or Paragraph
$des_allowed_tags = array(
    'a' => array(
        'href' => array(),
        'title' => array(),
        'class' => array()
    ),
    'img' => array(
        'alt' => array(),
        'src' => array()
    ),
    'br' => array(),
    'em' => array(),
    'strong' => array(),
);

?>


<!--Progress Levels-->
<div class="progress-levels medium">
                                                            
    <!--Skill Box Start-->
    
    <?php $testimonials = vc_param_group_parse_atts($colum_up_group);
                    foreach ($testimonials as $item): ?>

    <div class="progress-box wow fadeIn" data-wow-delay="100ms" data-wow-duration="<?php echo esc_html($item['s_external_link']) ?>ms">
        <div class="box-title"><?php echo wp_kses(wpautop($item['des']), $des_allowed_tags) ?></div>
        <div class="percent"></div>
        <div class="inner">
            <div class="bar">
                <div class="bar-innner"><div class="bar-fill" data-percent="<?php echo esc_html($item['head']) ?>"></div></div>
            </div>
         </div>
    </div>

    <?php endforeach; ?>
                                                            
    <!--Skill Box End-->
                                                                                                      
</div>



	<?php
	return ob_get_clean();

}
