<?php 
add_shortcode('counter_up','counter_up_section_func');
function counter_up_section_func($jekono){
	$result = shortcode_atts(array(
		'counter_up_group' =>'',
        
        'head' => '',
        'des' => '',
        'type' => 1,
        'link_to_page' => '',
        'external_link' => '',
        // 'service_style' => 1,
        'icon_type' => 1,
        'upload_icon' => '',
        'choose_icon' => '',
        'upload_profile_img' => '',
		
	),$jekono);

	extract($result);

	ob_start();



	?>

<?php

// For desc Or Paragraph
$des_allowed_tags = array(
    'a' => array(
        'href' => array(),
        'title' => array(),
        'class' => array()
    ),
    'img' => array(
        'alt' => array(),
        'src' => array()
    ),
    'br' => array(),
    'em' => array(),
    'strong' => array(),
);

?>

<!--Start funfact section-->

                    <div class="row">

                    <?php $testimonials = vc_param_group_parse_atts($counter_up_group);
                    foreach ($testimonials as $item): ?>

                        <div class="col-md-3 col-sm-6 col-xs-12">
                            <!--Start single  item-->
                            <div class="fact-content ">
                                <div class="content-area">
                                    <i class="<?php echo esc_attr($item['choose_icon']) ?>"></i>
                                    <h2 class="sF-counter" data-from="0" data-to="<?php echo esc_html($item['head']) ?>" data-speed="<?php echo esc_html($item['s_external_link']) ?>" data-refresh-interval="50"><?php echo esc_html($item['head']) ?></h2>
                                    <div class="border_services"></div>
                                    <p><?php echo wp_kses(wpautop($item['des']), $des_allowed_tags) ?></p>
                                </div>
                            </div>
                            <!--End single  item-->
                        </div>
        <?php endforeach; ?>
                        
                        
                        

                    </div>


        <!--End funfact section-->



	<?php
	return ob_get_clean();

}
