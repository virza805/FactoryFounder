<?php 
add_shortcode('btn','btn_section_func');
function btn_section_func($jekono){
	$result = shortcode_atts(array(
		'btn_group' =>'',
		
	),$jekono);

	extract($result);

	ob_start();



    ?>


<div class="view-button">
<?php 
    $testimonials = vc_param_group_parse_atts($btn_group);
        foreach ($testimonials as $item):
                    
?>
<?php 
    if($type == 1){
        $link_source = get_page_link($item['link_to_page']);
    }else{
        $link_source = $item['external_link'];
    } 
?>
<?php 
if($item['btn_style'] == 1) {
    echo '<a class="button-1 margin-rit-30 mgn-rit-10" href="'.esc_url($link_source).'">'.$item['btn'] .'</a>';
} elseif($item['btn_style'] == 2) {
    echo '<a class="button-2 margin-rit-30 mgn-rit-10" href="'.esc_url($link_source).'">'.$item['btn'] .'</a>';
} elseif($item['btn_style'] == 3) {
echo '<div class="subscribe_Now"><a href="'.esc_url($link_source).'">'.$item['btn'] .'</a></div>';
} else {
echo '<div class="newsletter_donate_Now"><a href="'.esc_url($link_source).'">'.$item['btn'] .'</a></div>';
}
    
?>  
<?php endforeach; ?>  
</div>
 
           
                    
	<?php
	return ob_get_clean();

}
